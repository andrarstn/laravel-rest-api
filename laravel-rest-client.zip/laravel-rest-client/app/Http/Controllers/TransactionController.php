<?php

namespace App\Http\Controllers;

use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;

class TransactionController extends Controller
{
    private $url_api = "http://192.168.1.11/api/transaction";
    private $cl;

    public function __construct()
    {
        $this->cl = new Client();
    }

    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $response = $this->cl->request('GET', $this->url_api);

        $responseBody = json_decode($response->getBody());
        $responseBody = $responseBody->data;

        return view('index', compact('responseBody'));
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function create()
    {
        //
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $data = [
            'title' => $request->input('title'),
            'amount' => $request->input('amount'),
            'type' => $request->input('typeTransaction'),
            'time' => date('Y-m-d H:i:s')
        ];

        
        $response = $this->cl->request('POST', $this->url_api,[
            'form_params' => $data
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return response()->json($result);
    }

    /**
     * Display the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {
        //
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function edit($id)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $data = [
            'title' => $request->input('title'),
            'amount' => $request->input('amount'),
            'type' => $request->input('type'),
            'time' => date('Y-m-d H:i:s')
        ];

        
        $response = $this->cl->request('PUT', $this->url_api."/$id",[
            'form_params' => $data
        ]);

        $result = json_decode($response->getBody()->getContents(), true);

        return response()->json($result);
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  int  $id
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $response = $this->cl->request('DELETE', $this->url_api.'/'.$id);

        $result = json_decode($response->getBody()->getContents(), true);

        return response()->json($result);
    }
}
