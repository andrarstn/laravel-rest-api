<!doctype html>
<html lang="en">

<head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">

    <!-- Bootstrap CSS -->
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/css/bootstrap.min.css" rel="stylesheet"
        integrity="sha384-+0n0xVW2eSR5OomGNYDnhzAbDsOXxcvSN1TPprVMTNDbiYZCxYbOOl7+AMvyTG2x" crossorigin="anonymous">

    <title>Rest Client</title>
</head>

<body>
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark mb-4">
        <div class="container">
            <a class="navbar-brand" href="#">Navbar</a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarNavAltMarkup"
                aria-controls="navbarNavAltMarkup" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="navbarNavAltMarkup">
                <div class="navbar-nav">
                    <a class="nav-link active" aria-current="page" href="/transaction">Home</a>
                    <button class="btn btn-success" type="button" data-bs-toggle="modal"
                        data-bs-target="#addDataModal">Tambah</button>
                </div>
            </div>
        </div>
    </nav>
    <div class="container">
        <h1 class="text-center text-secondary">Keuanganku</h1>
        <div id="itemRow">
            <div class="row">
                @foreach ($responseBody as $item)
                    <div class="col-md-3 mb-3">
                        <div class="card">
                            <div class="card-body">
                                <h5 class="card-title">{{ $item->title }}</h5>
                                <h6 class="card-subtitle mb-2 text-muted"><span
                                        class="badge bg-{{ $item->type == 'expense' ? 'danger' : 'success' }}">{{ $item->type }}</span>
                                </h6>
                                <p class="card-text">Rp{{ number_format($item->amount, 2, ',', '.') }}</p>
                                <p class="card-text">Waktu: {{ $item->time }}</p>
                                <button type="button" class="btn btn-sm btn-primary"
                                    onclick="editData('{{ $item->id }}','{{ $item->title }}','{{ $item->amount }}','{{ $item->type }}')">Ubah</button>
                                <button type="button" class="btn btn-sm btn-danger"
                                    onclick="deleteData('{{ $item->id }}')">Hapus</button>
                            </div>
                        </div>
                    </div>
                @endforeach
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="addDataModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Tambah Data Keuangan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="title" class="form-label">Judul</label>
                        <input type="text" class="form-control" id="title" placeholder="Belanja Sembako">
                    </div>
                    <div class="mb-3">
                        <label for="amount" class="form-label">Jumlah Uang</label>
                        <input type="number" class="form-control" id="amount">
                    </div>
                    <div class="mb-3">
                        <label for="typeTransaction" class="form-label">Tipe</label>
                        <select class="form-select" aria-label="Default select example" id="typeTransaction">
                            <option selected value="">Pilih tipe</option>
                            <option value="expense">Pengeluaran</option>
                            <option value="revenue">Pemasukan</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" class="btn btn-primary" id="saveButton">Simpan</button>
                </div>
            </div>
        </div>
    </div>

    <!-- Modal -->
    <div class="modal fade" id="editDataModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="exampleModalLabel">Edit Data Keuangan</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <input type="hidden" name="edit-id" id="edit-id">
                    <div class="mb-3">
                        <label for="edit-title" class="form-label">Judul</label>
                        <input type="text" class="form-control" id="edit-title" placeholder="Belanja Sembako">
                    </div>
                    <div class="mb-3">
                        <label for="edit-amount" class="form-label">Jumlah Uang</label>
                        <input type="number" class="form-control" id="edit-amount">
                    </div>
                    <div class="mb-3">
                        <label for="edit-typeTransaction" class="form-label">Tipe</label>
                        <select class="form-select" aria-label="Default select example" id="edit-typeTransaction">
                            <option selected value="">Pilih tipe</option>
                            <option value="expense">Pengeluaran</option>
                            <option value="revenue">Pemasukan</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Tutup</button>
                    <button type="button" class="btn btn-primary" id="editButton">Simpan</button>
                </div>
            </div>
        </div>
    </div>
    <!-- Optional JavaScript; choose one of the two! -->

    <!-- Option 1: Bootstrap Bundle with Popper -->
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.bundle.min.js"
        integrity="sha384-gtEjrD/SeCtmISkJkNUaaKMoLD0//ElJ19smozuHV6z3Iehds+3Ulb9Bn9Plx0x4" crossorigin="anonymous">
    </script>

    <!-- Option 2: Separate Popper and Bootstrap JS -->
    <!--
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.9.2/dist/umd/popper.min.js" integrity="sha384-IQsoLXl5PILFhosVNubq5LC7Qb9DXgDA9i+tQ8Zj3iwWAwPtgFTxbJ8NT4GN1R8p" crossorigin="anonymous"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.0.1/dist/js/bootstrap.min.js" integrity="sha384-Atwg2Pkwv9vp0ygtn1JAojH0nYbwNJLPhwyoVbhoPwBhjQPR5VtM2+xf0Uwh9KtT" crossorigin="anonymous"></script>
    -->

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.0/jquery.min.js"></script>
    <script>
        let modalAdd = new bootstrap.Modal(document.getElementById('addDataModal'))
        let modalEdit = new bootstrap.Modal(document.getElementById('editDataModal'))

        $("#saveButton").click(function() {
            let title = $("#title")
            let amount = $("#amount")
            let typeTransaction = $("#typeTransaction")
            $.ajax({
                url: "{{ url('/transaction') }}",
                type: 'POST',
                data: {
                    title: title.val(),
                    amount: amount.val(),
                    typeTransaction: typeTransaction.val()
                },
                success: function(response) {
                    if (response.message == "Transaction created") {
                        title.val('')
                        amount.val('')
                        typeTransaction.val('')
                        $("#itemRow").load(location.href + " #itemRow");
                        modalAdd.hide()
                    } else {
                        alert(response)
                    }
                },
                error: function() {
                    alert('error')
                }
            })
        })

        function editData(id, title, amount, type) {
            modalEdit.show()
            $("#edit-id").val(id)
            $("#edit-title").val(title)
            $("#edit-amount").val(amount)
            $("#edit-typeTransaction").val(type)
        }

        $("#editButton").click(function() {
            let id = $("#edit-id").val()
            let title = $("#edit-title").val()
            let amount = $("#edit-amount").val()
            let type = $("#edit-typeTransaction").val()

            console.log(id, title, amount, type);

            $.ajax({
                url: `{{ url('/transaction/${id}') }}`,
                type: 'PATCH',
                data: {
                    id: id,
                    title: title,
                    amount: amount,
                    type: type
                },
                success: function(response) {
                    if (response.message == "Transaction updated") {
                        $("#itemRow").load(location.href + " #itemRow");
                        modalEdit.hide()
                    } else {
                        alert(response)
                    }
                },
                error: function() {
                    alert('error')
                }
            })
        })

        function deleteData(id) {
            let confirmation = confirm('Yakin ingin menghapusnya?')
            if (confirmation == true) {
                $.ajax({
                    url: `{{ url('/transaction/${id}') }}`,
                    type: 'DELETE',
                    data: {
                        id: id,
                    },
                    success: function(response) {
                        if (response.message == "Transaction deleted") {
                            $("#itemRow").load(location.href + " #itemRow");
                        }
                    },
                    error: function() {
                        alert('error')
                    }
                })
            }
        }

    </script>
</body>

</html>
